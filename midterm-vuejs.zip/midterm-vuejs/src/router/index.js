import { createRouter, createWebHistory } from 'vue-router';
import Home from '../components/Home.vue';
import CreatePost from '../components/CreatePost.vue';
import UserPosts from '../components/UserPosts.vue';
import EditPost from '../components/EditPost.vue';
import PostDetail from '../components/PostDetail.vue';
import Profile from '../components/Profile.vue';

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home
  },
  {
    path: '/create-post',
    name: 'CreatePost',
    component: CreatePost
  },
  {
    path: '/my-posts',
    name: 'UserPosts',
    component: UserPosts
  },
  {
    path: '/edit-post/:id',
    name: 'EditPost',
    component: EditPost
  },
  {
    path: '/post/:id',
    name: 'PostDetail',
    component: PostDetail
  },
  {
    path: '/profile',
    name: 'Profile',
    component: Profile
  }
];

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
});

export default router;