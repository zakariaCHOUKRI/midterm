import { initializeApp } from "firebase/app";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, onAuthStateChanged, sendPasswordResetEmail } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
    apiKey: "AIzaSyBiEXF5dFekZgWejdJI1g5pv3VZnCM5eRo",
    authDomain: "midterm-vue.firebaseapp.com",
    projectId: "midterm-vue",
    storageBucket: "midterm-vue.firebasestorage.app",
    messagingSenderId: "194595738775",
    appId: "1:194595738775:web:372e5da7df25869273c5d2"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

export { auth, db, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, onAuthStateChanged, sendPasswordResetEmail };