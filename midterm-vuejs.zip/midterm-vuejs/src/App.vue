<template>
  <div id="app">
    <header class="d-flex justify-content-between p-3 bg-light">
      <div>
        <router-link to="/" class="btn btn-link">Home</router-link>
        <router-link v-if="user" to="/create-post" class="btn btn-link">Create Event</router-link>
        <router-link v-if="user" to="/my-posts" class="btn btn-link">My Events</router-link>
        <router-link v-if="user" to="/profile" class="btn btn-link">Profile</router-link>
      </div>
      <div>
        <button v-if="!user" class="btn btn-primary me-2" @click="showLogin = true">Login</button>
        <button v-if="!user" class="btn btn-secondary" @click="showRegister = true">Register</button>
        <button v-if="user" class="btn btn-danger" @click="logout">Logout</button>
      </div>
    </header>
    <LoginModal v-if="showLogin" @close="showLogin = false" @login="login" @forgot-password="forgotPassword" :error="loginError" />
    <RegisterModal v-if="showRegister" @close="showRegister = false" @register="register" :error="registerError" />
    <router-view/>
    <footer class="text-center p-3 bg-light">
      Made with ♥ by Zakaria CHOUKRI for the Midterm Exam
    </footer>
  </div>
</template>

<script>
import { auth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, onAuthStateChanged, sendPasswordResetEmail } from './firebase';
import LoginModal from './components/LoginModal.vue';
import RegisterModal from './components/RegisterModal.vue';

export default {
  name: 'App',
  components: {
    LoginModal,
    RegisterModal
  },
  data() {
    return {
      user: null,
      showLogin: false,
      showRegister: false,
      loginError: '',
      registerError: ''
    };
  },
  created() {
    onAuthStateChanged(auth, user => {
      this.user = user;
    });
  },
  methods: {
    async login(email, password) {
      try {
        await signInWithEmailAndPassword(auth, email, password);
        this.showLogin = false;
        this.loginError = '';
      } catch (error) {
        this.loginError = error.message;
      }
    },
    async register(email, password, additionalData) {
      try {
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        const user = userCredential.user;
        // Save additional data to the user's profile or database
        console.log('Additional Data:', additionalData);
        this.showRegister = false;
        this.registerError = '';
      } catch (error) {
        this.registerError = error.message;
      }
    },
    async logout() {
      try {
        await signOut(auth);
      } catch (error) {
        console.error(error);
      }
    },
    async forgotPassword(email) {
      try {
        await sendPasswordResetEmail(auth, email);
        alert('Password reset email sent!');
      } catch (error) {
        this.loginError = error.message;
      }
    }
  }
};
</script>