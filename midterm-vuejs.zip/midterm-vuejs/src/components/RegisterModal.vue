<template>
  <div class="modal d-block">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Register</h5>
          <button type="button" class="btn-close" @click="$emit('close')"></button>
        </div>
        <div class="modal-body">
          <form @submit.prevent="register">
            <div class="mb-3">
              <label for="email" class="form-label">Email</label>
              <input v-model="email" type="email" class="form-control" id="email" required>
            </div>
            <div class="mb-3">
              <label for="password" class="form-label">Password</label>
              <input v-model="password" type="password" class="form-control" id="password" required>
            </div>
            <div class="mb-3">
              <label for="username" class="form-label">Username</label>
              <input v-model="username" type="text" class="form-control" id="username" required>
            </div>
            <div class="mb-3">
              <label for="dob" class="form-label">Date of Birth</label>
              <input v-model="dob" type="date" class="form-control" id="dob" required>
            </div>
            <div class="mb-3">
              <label for="gender" class="form-label">Gender</label>
              <select v-model="gender" class="form-select" id="gender" required>
                <option value="" disabled>Select your gender</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
              </select>
            </div>
            <div class="mb-3">
              <label for="phone" class="form-label">Phone Number</label>
              <input v-model="phone" type="tel" class="form-control" id="phone" required>
            </div>
            <div v-if="error" class="alert alert-danger">{{ error }}</div>
            <button type="submit" class="btn btn-primary">Register</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    error: String
  },
  data() {
    return {
      email: '',
      password: '',
      username: '',
      dob: '',
      gender: '',
      phone: ''
    };
  },
  methods: {
    register() {
      const additionalData = {
        username: this.username,
        dob: this.dob,
        gender: this.gender,
        phone: this.phone
      };
      this.$emit('register', this.email, this.password, additionalData);
    }
  }
};
</script>