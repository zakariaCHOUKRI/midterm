<template>
    <div class="container mt-5">
      <h2>Profile</h2>
      <form @submit.prevent="updateProfile">
        <div class="mb-3">
          <label for="email" class="form-label">Email</label>
          <input v-model="email" type="email" class="form-control" id="email" required>
        </div>
        <div class="mb-3">
          <label for="username" class="form-label">Username</label>
          <input v-model="username" type="text" class="form-control" id="username" required>
        </div>
        <div class="mb-3">
          <label for="dob" class="form-label">Date of Birth</label>
          <input v-model="dob" type="date" class="form-control" id="dob" required>
        </div>
        <div class="mb-3">
          <label for="gender" class="form-label">Gender</label>
          <select v-model="gender" class="form-select" id="gender" required>
            <option value="" disabled>Select your gender</option>
            <option value="male">Male</option>
            <option value="female">Female</option>
            <option value="other">Other</option>
          </select>
        </div>
        <div class="mb-3">
          <label for="phone" class="form-label">Phone Number</label>
          <input v-model="phone" type="tel" class="form-control" id="phone" required>
        </div>
        <button type="submit" class="btn btn-primary">Update Profile</button>
      </form>
    </div>
  </template>
  
  <script>
  import { auth, db } from '../firebase';
  import { doc, getDoc, updateDoc } from 'firebase/firestore';
  
  export default {
    data() {
      return {
        email: '',
        username: '',
        dob: '',
        gender: '',
        phone: ''
      };
    },
    async created() {
      const user = auth.currentUser;
      if (!user) {
        this.$router.push('/');
        return;
      }
      const userDoc = await getDoc(doc(db, 'users', user.uid));
      if (userDoc.exists()) {
        const userData = userDoc.data();
        this.email = user.email;
        this.username = userData.username;
        this.dob = userData.dob;
        this.gender = userData.gender;
        this.phone = userData.phone;
      }
    },
    methods: {
      async updateProfile() {
        const user = auth.currentUser;
        if (!user) {
          alert('You must be logged in to update your profile.');
          return;
        }
        try {
          await updateDoc(doc(db, 'users', user.uid), {
            username: this.username,
            dob: this.dob,
            gender: this.gender,
            phone: this.phone
          });
          alert('Profile updated successfully!');
        } catch (error) {
          console.error('Error updating profile:', error);
        }
      }
    }
  };
  </script>