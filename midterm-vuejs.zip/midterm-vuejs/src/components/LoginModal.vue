<template>
  <div class="modal d-block">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Login</h5>
          <button type="button" class="btn-close" @click="$emit('close')"></button>
        </div>
        <div class="modal-body">
          <form @submit.prevent="login">
            <div class="mb-3">
              <label for="email" class="form-label">Email</label>
              <input v-model="email" type="email" class="form-control" id="email" required>
            </div>
            <div class="mb-3">
              <label for="password" class="form-label">Password</label>
              <input v-model="password" type="password" class="form-control" id="password" required>
            </div>
            <div v-if="error" class="alert alert-danger">{{ error }}</div>
            <button type="submit" class="btn btn-primary">Login</button>
          </form>
          <div class="mt-3">
            <a href="#" @click.prevent="forgotPassword">Forgot Password?</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    error: String
  },
  data() {
    return {
      email: '',
      password: ''
    };
  },
  methods: {
    login() {
      this.$emit('login', this.email, this.password);
    },
    forgotPassword() {
      this.$emit('forgot-password', this.email);
    }
  }
};
</script>