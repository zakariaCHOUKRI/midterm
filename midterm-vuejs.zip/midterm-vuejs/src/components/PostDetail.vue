<template>
  <div class="container mt-5">
    <div v-if="post" class="card">
      <img :src="post.image" class="card-img-top" alt="Event Image">
      <div class="card-body">
        <h5 class="card-title">{{ post.title }}</h5>
        <p class="card-text">{{ post.description }}</p>
        <p class="card-text"><strong>Price:</strong> ${{ post.price }}</p>
        <p class="card-text"><strong>Date of Event:</strong> {{ post.dov }}</p>
        <p class="card-text"><strong>Number of Yes Votes:</strong> {{ Object.values(post.votes || {}).filter(vote => vote === 'yes').length }}</p>
        <p class="card-text"><strong>Number of No Votes:</strong> {{ Object.values(post.votes || {}).filter(vote => vote === 'no').length }}</p>
        <button id="voteyesbtn" class="btn btn-success mt-2" @click="voteyes(post.id)">Vote Yes</button>
        <button id="votenobtn" class="btn btn-danger mt-2" @click="voteno(post.id)">Vote No</button>
      </div>
    </div>
    <div v-else>
      <p>Loading...</p>
    </div>

    <div class="mt-5">
      <h3>Comments</h3>
      <div v-if="user">
        <form @submit.prevent="addComment">
          <div class="mb-3">
            <label for="comment" class="form-label">Add a Comment</label>
            <textarea v-model="newComment" class="form-control" id="comment" required></textarea>
          </div>
          <button type="submit" class="btn btn-primary">Add Comment</button>
        </form>
      </div>
      <div v-else>
        <p>Please log in to add a comment.</p>
      </div>

      <div v-for="comment in comments" :key="comment.id" class="card mt-3">
        <div class="card-body">
          <p class="card-text">{{ comment.text }}</p>
          <p class="card-text"><small class="text-muted">By {{ comment.userId }}</small></p>
          <div v-if="user && user.uid === comment.userId">
            <button class="btn btn-warning me-2" @click="editComment(comment)">Edit</button>
            <button class="btn btn-danger" @click="deleteComment(comment.id)">Delete</button>
          </div>
        </div>
      </div>
    </div>

    <div v-if="editingComment" class="modal d-block">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Edit Comment</h5>
            <button type="button" class="btn-close" @click="cancelEdit"></button>
          </div>
          <div class="modal-body">
            <form @submit.prevent="updateComment">
              <div class="mb-3">
                <label for="editComment" class="form-label">Edit Comment</label>
                <textarea v-model="editingComment.text" class="form-control" id="editComment" required></textarea>
              </div>
              <button type="submit" class="btn btn-primary">Update Comment</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { db, auth } from '../firebase';
import { doc, getDoc, collection, addDoc, getDocs, updateDoc, deleteDoc, query, where, serverTimestamp, setDoc } from 'firebase/firestore';

export default {
  data() {
    return {
      post: null,
      comments: [],
      newComment: '',
      editingComment: null,
      user: null
    };
  },
  async created() {
    const postId = this.$route.params.id;
    const postDoc = await getDoc(doc(db, 'posts', postId));
    if (postDoc.exists()) {
      this.post = postDoc.data();
      this.post.id = postDoc.id;
      this.fetchComments();
    } else {
      this.$router.push('/');
    }

    auth.onAuthStateChanged(user => {
      this.user = user;
    });
  },
  methods: {
    async fetchComments() {
      const commentsQuery = query(collection(db, 'posts', this.post.id, 'comments'));
      const querySnapshot = await getDocs(commentsQuery);
      this.comments = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    },
    async addComment() {
      if (!this.user) {
        alert('You must be logged in to add a comment.');
        return;
      }
      try {
        await addDoc(collection(db, 'posts', this.post.id, 'comments'), {
          text: this.newComment,
          userId: this.user.uid,
          createdAt: serverTimestamp()
        });
        this.newComment = '';
        this.fetchComments();
      } catch (error) {
        console.error('Error adding comment:', error);
      }
    },
    editComment(comment) {
      this.editingComment = { ...comment };
    },
    async updateComment() {
      try {
        await updateDoc(doc(db, 'posts', this.post.id, 'comments', this.editingComment.id), {
          text: this.editingComment.text
        });
        this.editingComment = null;
        this.fetchComments();
      } catch (error) {
        console.error('Error updating comment:', error);
      }
    },
    async deleteComment(commentId) {
      try {
        await deleteDoc(doc(db, 'posts', this.post.id, 'comments', commentId));
        this.fetchComments();
      } catch (error) {
        console.error('Error deleting comment:', error);
      }
    },
    cancelEdit() {
      this.editingComment = null;
    },
    async voteyes(id) {
      const postDoc = doc(db, 'posts', id);
      const post = await getDoc(postDoc);
      const data = post.data();
      const votes = data.votes || {};
      const user = auth.currentUser;
      votes[user.uid] = 'yes';
      await setDoc(postDoc, { votes }, { merge: true });
      this.post = { ...this.post, votes };
    },
    async voteno(id) {
      const postDoc = doc(db, 'posts', id);
      const post = await getDoc(postDoc);
      const data = post.data();
      const votes = data.votes || {};
      const user = auth.currentUser;
      votes[user.uid] = 'no';
      await setDoc(postDoc, { votes }, { merge: true });
      this.post = { ...this.post, votes };
    }
  },
  beforeMount() {
    const postId = this.$route.params.id;
    const postDoc = doc(db, 'posts', postId);
    getDoc(postDoc).then(post => {
      const data = post.data();
      if (!auth.currentUser || new Date(data.dov) < new Date()) {
        document.querySelectorAll('#voteyesbtn, #votenobtn').forEach(button => button.disabled = true);
        alert("this event is already past, so you can't vote!");
      }
    });
  }
};
</script>