<template>
  <div class="container mt-5">
    <h2>Create an event</h2>
    <form @submit.prevent="createPost">
      <div class="mb-3">
        <label for="title" class="form-label">Title</label>
        <input v-model="title" type="text" class="form-control" id="title" required>
      </div>
      <div class="mb-3">
        <label for="image" class="form-label">Image URL</label>
        <input v-model="image" type="text" class="form-control" id="image" required>
      </div>
      <div class="mb-3">
        <label for="description" class="form-label">Description</label>
        <textarea v-model="description" class="form-control" id="description" required></textarea>
      </div>
      <div class="mb-3">
        <label for="dov" class="form-label">Date of Event</label>
        <input v-model="dov" type="date" class="form-control" id="dov" required>
      </div>
      <div class="mb-3">
        <label for="price" class="form-label">Price</label>
        <input v-model="price" type="number" class="form-control" id="price" required>
      </div>
      <button type="submit" class="btn btn-primary">Create Event</button>
    </form>
  </div>
</template>

<script>
import { db, auth } from '../firebase';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';

export default {
  data() {
    return {
      title: '',
      image: '',
      description: '',
      price: '',
      dov: ''
    };
  },
  methods: {
    async createPost() {
      try {
        const user = auth.currentUser;
        if (!user) {
          throw new Error('User not authenticated');
        }
        await addDoc(collection(db, 'posts'), {
          title: this.title,
          image: this.image,
          description: this.description,
          price: this.price,
          createdAt: serverTimestamp(),
          userId: user.uid,
          dov: this.dov // this means Date Of eVent (i should have made it doe)
        });
        this.$router.push('/');
      } catch (error) {
        console.error('Error creating post:', error);
      }
    }
  }
};
</script>