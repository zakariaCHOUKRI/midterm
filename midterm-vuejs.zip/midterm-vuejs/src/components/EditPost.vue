<template>
    <div class="container mt-5">
      <h2>Edit Event</h2>
      <form @submit.prevent="updatePost">
        <div class="mb-3">
          <label for="title" class="form-label">Title</label>
          <input v-model="title" type="text" class="form-control" id="title" required>
        </div>
        <div class="mb-3">
          <label for="image" class="form-label">Image URL</label>
          <input v-model="image" type="text" class="form-control" id="image" required>
        </div>
        <div class="mb-3">
          <label for="description" class="form-label">Description</label>
          <textarea v-model="description" class="form-control" id="description" required></textarea>
        </div>
        <div class="mb-3">
          <label for="dov" class="form-label">Date of Event</label>
          <input v-model="dov" type="date" class="form-control" id="dov" required>
        </div>
        <div class="mb-3">
          <label for="price" class="form-label">Price</label>
          <input v-model="price" type="number" class="form-control" id="price" required>
        </div>
        <button type="submit" class="btn btn-primary">Update Event</button>
      </form>
    </div>
  </template>
  
  <script>
  import { db } from '../firebase';
  import { doc, getDoc, updateDoc } from 'firebase/firestore';
  
  export default {
    data() {
      return {
        title: '',
        image: '',
        description: '',
        price: '',
        dov: ''
      };
    },
    async created() {
      const postId = this.$route.params.id;
      const postDoc = await getDoc(doc(db, 'posts', postId));
      if (postDoc.exists()) {
        const post = postDoc.data();
        this.title = post.title;
        this.image = post.image;
        this.description = post.description;
        this.price = post.price;
        this.dov = post.dov;
      } else {
        this.$router.push('/');
      }
    },
    methods: {
      async updatePost() {
        try {
          const postId = this.$route.params.id;
          await updateDoc(doc(db, 'posts', postId), {
            title: this.title,
            image: this.image,
            description: this.description,
            price: this.price,
            dov: this.dov
          });
          this.$router.push('/my-posts');
        } catch (error) {
          console.error('Error updating event:', error);
        }
      }
    }
  };
  </script>