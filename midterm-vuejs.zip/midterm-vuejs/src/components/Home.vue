<template>
  <div class="container mt-5">
    <h2>All Events</h2>
    <div class="row">
      <div class="col-md-4" v-for="post in filteredPosts" :key="post.id">
        <div class="card mb-4">
          <img :src="post.image" class="card-img-top" alt="Event Image">
          <div class="card-body">
            <h5 class="card-title">{{ post.title }}</h5>
            <p class="card-text">{{ post.description }}</p>
            <p class="card-text"><strong>Price:</strong> ${{ post.price }}</p>
            <p class="card-text"><strong>Date of Event:</strong> {{ post.dov }}</p>
            <p class="card-text"><strong>Number of Yes Votes:</strong> {{ Object.values(post.votes || {}).filter(vote => vote === 'yes').length }}</p>
            <p class="card-text"><strong>Number of No Votes:</strong> {{ Object.values(post.votes || {}).filter(vote => vote === 'no').length }}</p>
            <router-link :to="{ name: 'PostDetail', params: { id: post.id } }" class="btn btn-primary">View Event</router-link>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { db, auth } from '../firebase';
import { collection, getDocs, doc, setDoc, getDoc } from 'firebase/firestore';

export default {
  data() {
    return {
      posts: [],
      searchQuery: ''
    };
  },
  computed: {
    filteredPosts() {
      if (!this.searchQuery) {
        return this.posts;
      }
      const query = this.searchQuery.toLowerCase();
      return this.posts.filter(post => 
        post.title.toLowerCase().includes(query) || 
        post.description.toLowerCase().includes(query)
      );
    }
  },
  async created() {
    const querySnapshot = await getDocs(collection(db, 'posts'));
    this.posts = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
  },
  methods: {
    searchPosts() {
    }
  }
};


</script>